-- Esquema de base de datos para sistema de inventario de videojuegos
CREATE DATABASE IF NOT EXISTS videojuegos;
USE videojuegos;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    email VARCHAR(100),
    contraseña VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS videojuegos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100),
    plataforma VARCHAR(50),
    genero VARCHAR(50),
    estado VARCHAR(50),
    fecha_adquisicion DATE,
    usuario_id INT,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
