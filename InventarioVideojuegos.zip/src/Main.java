public class Main {
    public static void main(String[] args) {
        if (ConexionMySQL.conectar() != null) {
            System.out.println("Conexión exitosa a la base de datos MySQL.");
        } else {
            System.out.println("No se pudo conectar a la base de datos.");
        }
    }
}
